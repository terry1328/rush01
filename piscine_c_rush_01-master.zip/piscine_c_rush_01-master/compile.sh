#!/bin/bash
gcc -Wall -Wextra -Werror -o rush-1 *.c
